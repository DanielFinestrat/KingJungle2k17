/* 
 * File:   Entidad.cpp
 * Author: daniel
 * 
 * Created on 26 de marzo de 2017, 13:57
 */

#include "../headerfiles/Entidad.h"

Entidad::Entidad() {
}

Entidad::Entidad(const Entidad& orig) {
}

void Entidad::Render() {
}

string Entidad::getTag(){
    return tag;
}

Entidad::~Entidad() {
}

